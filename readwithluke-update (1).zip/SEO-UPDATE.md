# Read With Luke — website cleanup and SEO update

Prepared October 3, 2026. These are source-code changes, not a live deployment.

## Put the update into GitHub

1. Download and extract `readwithluke-update.zip` on your computer.
2. Open `colorhackers/readwithluke` on GitHub. Create a branch called `seo-cleanup` from the current production branch so you can review the changes first.
3. At the repository root, use **Add file → Upload files**. Drag in the extracted **app** and **lib** folders, **next.config.ts**, and **package-lock.json**. Preserve the nested folders, including `(app)` and `[bookSlug]`.
4. Commit the upload to `seo-cleanup`. Do not delete the existing app or lib folders: the ZIP contains only new and changed files, and must be merged into the existing project. Do not upload the ZIP itself as website source.
5. If your Vercel integration creates branch previews, open that preview. Keep the same environment variables already used by your site. No database migration or new paid service is required.
6. Verify the items under “Preview checklist” below. Then merge the branch into your production branch to use your existing deployment process.

The full `readwithluke-main.zip` is also supplied with the updated project. Use the small update ZIP for GitHub web uploads; the full ZIP includes the original large artwork files. No node_modules, build output, test credentials, mock data, or local test servers are included.

## What changed

### Public pages and discovery

- Home, Books, Learning, and Free Reads now fetch their public content on the server. Book links and covers are present in the rendered HTML without waiting for client-side effects.
- Books and Learning share a clean catalog layout: smaller headings, topic filters above the grid, four columns on tablets/desktops and two on phones, descriptive links, and 16 items per page.
- Pagination uses real URLs and links. Each unfiltered page has a self-referencing canonical URL; filtered variants remain noindex. Invalid page numbers beyond the collection return a not-found response.
- Temporary database failures use a retry screen rather than claiming that all books disappeared. No published stories in a selected category produces an honest empty-category state.
- Main navigation now says Books, Learning, Read Free, About. The unfinished Learn to Read page still exists but is noindex and is no longer promoted in the main navigation.
- Homepage copy explains the ages, format, and audio read-along; Read Free is the primary action. The original visual identity is retained. Cover rails can be scrolled and no longer automatically move.
- Fixed the footer overflow on tablets and reduced excess footer height on phones. Footer retains the newsletter form, removes inactive social buttons and the link to the missing leaderboard route, and adds useful public links.
- Fixed the mobile menu close button being hidden under the header. Added Escape, keyboard focus management, and body scroll locking.

### Book and learning previews

- Corrected book canonical and sharing URLs from /library/slug to /books/slug, consistently using https://www.readwithluke.com.
- Old /library/slug links permanently redirect to /books/slug (Next.js uses HTTP 308).
- Previews are limited to published items; missing and unpublished slugs return notFound rather than a successful “not found” page.
- Added breadcrumbs, a cover, factual page counts, existing age ranges, synopsis, reading discussion prompts, expandable FAQs, and related adventures.
- Added tailored editorial content for Inside What? based on the supplied synopsis and comments. Other adventures use their existing published descriptions and topics. No plot events, author credits, formal reading levels, reviews, awards, or credentials have been invented.
- Added Book schema for storybooks, LearningResource schema for learning adventures, BreadcrumbList schema for both, WebSite schema on home, and an Organization entity on About.
- Preserved each item's admin SEO title, description, image and noindex overrides. Defaults apply only when the corresponding override is empty.
- Removed inert favorite/bookmark buttons from previews. Existing reader controls and access gates were not rewritten.
- Fixed sharing: absolute URLs are no longer prefixed with a second site origin, and cancellation/copy failures are handled.

### Images and metadata

- Added responsive Next.js Image optimization to catalog covers, catalog backgrounds, featured artwork, preview artwork/covers, related adventures, home cover rails, and free adventure artwork. The existing public Supabase storage host is narrowly allowlisted. Unknown image hosts render without optimization rather than failing the page.
- Below-the-fold covers use lazy loading; main preview artwork is preloaded. The animated homepage hero remains unchanged and should be measured separately on the live site.
- Corrected the font format declaration, added font-display: swap, and moved the Tailwind import to the top of the stylesheet.
- Added unique metadata for the main public pages, canonical URLs, the metadata base origin, consistent social sharing previews and max-image-preview:large.
- The sitemap now includes published book and learning preview URLs, omits items marked seo_noindex, omits readers/private pages, and does not invent last-modified timestamps. It reads the full public catalog using range requests.
- Added robots.txt and extended noindex headers to the actual signup, password, dashboard and profile routes. Robots allows crawling those pages so their noindex headers can be read. These directives are not access controls.
- Repaired the existing dependency lockfile mismatch found during installation; dependency versions in package.json were not changed.

## Your supplied SEO comments: implemented and deferred

Implemented: correct canonicals and redirects, relevant metadata, factual structured data, richer public previews, FAQs for parents, related links, image optimization, server rendering, truthful age/page information and improved keyboard usability.

Deferred until there is verified source material: author biographies/credentials; real customer testimonials and review ratings; book-specific character profiles, teaching outcomes and independently assessed reading levels; trailers; downloadable worksheets beyond existing ones; a multi-page “look inside” sample for paid books; and outreach to educators or reviewers. No messages were sent to anyone. The existing reader gates, payment logic and public database permissions were not changed.

Some comments overstate what SEO can promise. Book markup helps describe content but is not a guarantee of special Google book buttons; Google announced the phase-out of Book Actions in 2025. FAQ rich results are generally limited to authoritative government/health sites, so the visible FAQ is built for parents without a promise of a special snippet. Adding schema, longer sessions, hidden keyword-heavy graphics, or canonicals does not guarantee a ranking or transfer “100% SEO credit.” Do not remove or redirect distinct books simply because traffic is low.

References:
- https://developers.google.com/search/blog/2025/06/simplifying-search-results
- https://developers.google.com/search/blog/2023/08/howto-faq-changes
- https://developers.google.com/search/docs/appearance/structured-data/sd-policies
- https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls

## Preview checklist

- Open /, /library, /learn, /free-reads and an existing book and learning preview. Check that real covers, descriptions and counts load using your Vercel/Supabase configuration.
- Try category filters, page 2 (if available), and navigation on an iPhone and iPad.
- Open and close the mobile menu; use Tab and Escape on a keyboard.
- Open a FAQ and use Share. Check a missing slug and an old /library/book-slug link.
- Confirm your two currently free adventures can still be read without signing in. Confirm a paid adventure still requires membership. Check account login and checkout using your existing testing process before production.
- Inspect /sitemap.xml and /robots.txt on the production domain after deployment. Check an item marked SEO noindex is absent from the sitemap.
- Check a book page's canonical points to its own /books/ URL, and its title/description follow the admin overrides when populated.
- In Google Search Console, submit https://www.readwithluke.com/sitemap.xml. Use URL Inspection on home, Books, Learning, Free Reads and Inside What? to verify Google's rendered content and selected canonical.
- Measure live mobile Core Web Vitals and image delivery after deployment. No live Lighthouse/PageSpeed score is claimed here.

## Remaining content to supply

The original footer still contains “Privacy • Terms” as plain text with no real destination pages. Supply the actual approved policy text/URLs so these can become working links; this update does not fabricate legal policies. Any social links or testimonials should likewise use your real destinations and approved content.

To extend tailored book content, edit lib/book-editorial.ts using the existing Inside What? entry as a pattern. Keep the facts consistent with the story. Use the existing admin SEO fields for preferred search snippets.

## Validation

See VALIDATION.txt in this package for the completed build and test results. Local route and layout tests used isolated sample catalog data and placeholder environment settings. They do not verify your live Supabase policies, real image delivery from all storage URLs, payments, email sending, Search Console indexing, or rankings. Your live site was not modified.
