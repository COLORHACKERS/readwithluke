import Link from "next/link";
import ContentImage from "./components/ContentImage";
import Header from "./components/Header";
import Footer from "@/app/components/Footer";
import { getCatalog } from "@/lib/public-catalog";
import { pageMetadata, SITE_DESCRIPTION, SITE_URL, jsonLd } from "@/lib/seo";
import "./home.css";

type Book = {
  id: string;
  title: string;
  slug: string;
  description: string | null;
  cover_url?: string | null;
  hero_url?: string | null;
  image_url?: string | null;
  age_range?: string | null;
  category?: string | null;
  created_at?: string;
};

type LearnItem = {
  id: string;
  title: string;
  slug: string;
  description: string | null;
  cover_url?: string | null;
  image_url?: string | null;
  category?: string | null;
  created_at?: string;
};

function fillToSix<T>(items: T[]) {
  if (!items.length) {
    return [];
  }

  return Array.from({ length: 6 }, (_, index) => {
    return items[index % items.length];
  });
}

function getBookFeatureImage(book: Book) {
  return (
    book.hero_url ||
    book.image_url ||
    book.cover_url ||
    "/images/6to5ratio.png"
  );
}

function getBookCover(book: Book) {
  return (
    book.cover_url ||
    book.image_url ||
    book.hero_url ||
    "/images/6to5ratio.png"
  );
}


function getLearnImage(item: LearnItem) {
  return (
    item.image_url ||
    item.cover_url ||
    "/images/6to5ratio.png"
  );
}

function getLearnCover(item: LearnItem) {
  return (
    item.cover_url ||
    item.image_url ||
    "/images/6to5ratio.png"
  );
}
export const metadata = pageMetadata("Online Books & Read-Along Stories for Kids", SITE_DESCRIPTION, "/");

export default async function Home() {
  const [allBooks, allLearnItems] = await Promise.all([getCatalog("books"), getCatalog("learn_items")]);
  const books = allBooks.slice(0, 6);
  const learnItems = allLearnItems.slice(0, 6);

  const featuredBook = books[0];
  const featuredLearn = learnItems[0];

  const marqueeBooks = fillToSix(books);
  const marqueeLearnItems = fillToSix(learnItems);

  return (
    <>
      <Header />
<main className="homePage">
  <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd({
    "@context": "https://schema.org", "@type": "WebSite", name: "Read With Luke", url: SITE_URL,
    description: SITE_DESCRIPTION, inLanguage: "en"
  }) }} />
  {/* NEW CINEMATIC HERO */}
  <section className="homeMovieHero">
    <img
      src="https://elfwdmgutfsdigijpfae.supabase.co/storage/v1/object/public/book-images/gateway/1787962304326-e7u2mqtx2xr.gif"
      alt="Read With Luke cinematic reading adventure"
      className="homeMovieHeroImage"
    />

    <div className="homeMovieHeroShade" />

    <div className="homeAlign homeMovieHeroInner">
      <div className="homeMovieHeroContent">
        <div className="homeMovieEyebrow">
          ★ ORIGINAL READING ADVENTURES
        </div>

        <h1>
          ONLINE BOOKS
          <br />
          FOR KIDS!
        </h1>

        <p>
          Original stories for ages 5–10, with cinematic artwork and audio read-along.
          Read together, listen with Luke, and discover something new.
        </p>

        <div className="homeMovieActions">
          <Link
            href="/free-reads"
            className="homeMoviePrimary"
          >
            READ FREE →
          </Link>

          <Link
            href="/library"
            className="homeMovieSecondary"
          >
            EXPLORE BOOKS
          </Link>
        </div>
      </div>

      <div className="homeMovieBottom">
        <span>● CINEMATIC STORIES</span>
        <span>◆ AGES 5–10</span>
        <span>★ NEW ADVENTURES ADDED</span>
      </div>
    </div>
  </section>

  {/* LARGE CREAM HOMEPAGE PANEL */}

        {/* LARGE CREAM HOMEPAGE PANEL */}
        <div className="homeContentShell">
          {/* TWO WORLDS */}
          <section className="homeWorldsSection">
            <div className="homeCenteredHeading">
              <span aria-hidden="true">✦</span>
              <h2>One Membership. Two Worlds to Explore.</h2>
              <span aria-hidden="true">✦</span>
            </div>

            <div className="homeWorldGrid">
              {featuredBook && (
                <Link href="/library" className="homeWorldCard">
                  <img loading="lazy" decoding="async"
                    src={getBookFeatureImage(featuredBook)}
                    alt="Read With Luke"
                  />

                  <div className="homeWorldShade" />

                  <div className="homeWorldContent">
                    <h3>Read With Luke</h3>

                    <p>
                      Mysteries, friendships, funny adventures, magical worlds,
                      and heartfelt stories children actually want to finish.
                    </p>

                    <span className="homeWorldButton">
                      Explore the Stories
                      <span aria-hidden="true">→</span>
                    </span>
                  </div>
                </Link>
              )}

              {featuredLearn && (
         <Link href="/learn" className="homeWorldCard">
  <img loading="lazy" decoding="async"
    src={getLearnImage(featuredLearn)}
    alt={featuredLearn.title}
  />

                  <div className="homeWorldShade" />

                  <div className="homeWorldContent">
                    <h3>Learn With Luke</h3>

                    <p>
                      Space, weather, the human body, nature, and everyday
                      mysteries explained through fascinating visual
                      adventures.
                    </p>

                    <span className="homeWorldButton">
                      Explore What’s Waiting
                      <span aria-hidden="true">→</span>
                    </span>
                  </div>
                </Link>
              )}
            </div>
          </section>

          {/* BOOK READER PREVIEW */}
         <section className="homeInsideSection" id="inside">
  <div className="homeInsideCopy">
    <h2>
      Not Just Beautiful Covers.
    
      Whole Worlds to Read Through.
    </h2>

    <p>
      Every adventure combines easy-to-read text, cinematic artwork,
      memorable characters, and page-by-page discovery.
    </p>

   <div className="homeInsideBenefits">
  <div className="insideBenefitItem">
    <img loading="lazy" decoding="async"
      src="/images/icon-cinematic-reading.png"
      alt="Open magical storybook icon"
      className="insideBenefitImage"
    />
    <strong>Cinematic Reading</strong>
  </div>

  <div className="insideBenefitItem">
    <img loading="lazy" decoding="async"
      src="/images/icon-easy-to-read.png"
      alt="Easy-to-read letter card icon"
      className="insideBenefitImage"
    />
    <strong>Easy-to-Read</strong>
  </div>

  <div className="insideBenefitItem">
    <img loading="lazy" decoding="async"
      src="/images/icon-fun-rewards.png"
      alt="Reward coins and badge icon"
      className="insideBenefitImage"
    />
    <strong>Fun Rewards</strong>
  </div>

  <div className="insideBenefitItem">
    <img loading="lazy" decoding="async"
      src="/images/icon-safe-ad-free.png"
      alt="Shield with heart icon for safe ad-free environment"
      className="insideBenefitImage"
    />
    <strong>Safe, Ad-Free</strong>
  </div>
</div>

    {featuredBook && (
<Link
  href="/learn/the-moon-s-secret-powers-part-2/read?page=1"
  className="homeFreeStoryButton"
>
  TRY A LEARNING STORY FOR FREE!
  <span aria-hidden="true">→</span>
</Link>
    )}
  </div>

  <div className="homeIpadImageWrap">
    <img loading="lazy" decoding="async"
      src="/images/ipad002.png"
      alt="Read With Luke interactive story reader"
      className="homeIpadImage"
    />
  </div>
</section>

{/* BOOK MARQUEE */}
        
          {marqueeBooks.length > 0 && (
            <section className="homeRailSection">
              <div className="homeRailHeading">
                <h2>Adventures They Can’t Wait to Read</h2>

                <Link href="/library">
                  View All
                  <span aria-hidden="true">→</span>
                </Link>
              </div>

              <div className="homeRailWindow">
                <div className="homeRailTrack">
                  {[0, 1].map((setNumber) => (
                    <div
                      className="homeRailSet"
                      key={`book-set-${setNumber}`}
                      aria-hidden={setNumber === 1}
                    >
                      {marqueeBooks.map((book, index) => (
                        <Link
                          href={`/books/${book.slug}`}
                          className="homeRailCard"
                          key={`${setNumber}-${book.id}-${index}`}
                          tabIndex={setNumber === 1 ? -1 : undefined}
                        >
                       

                          <ContentImage width={400} height={600} sizes="(max-width:600px) 65vw, 260px" loading="lazy"
                            src={getBookCover(book)}
                            alt={setNumber === 0 ? book.title : ""}
                          />

                          <div className="homeRailCardShade" />

                          
                        </Link>
                      ))}
                    </div>
                  ))}
                </div>
              </div>
            </section>
          )}

          {/* LEARNING MARQUEE */}
          {marqueeLearnItems.length > 0 && (
            <section className="homeRailSection homeLearningRailSection">
              <div className="homeRailHeading">
                <h2>New Things to Discover With Luke</h2>

                <Link href="/learn">
                  View All
                  <span aria-hidden="true">→</span>
                </Link>
              </div>

              <div className="homeRailWindow">
                <div className="homeRailTrack homeRailTrackReverse">
                  {[0, 1].map((setNumber) => (
                    <div
                      className="homeRailSet"
                      key={`learn-set-${setNumber}`}
                      aria-hidden={setNumber === 1}
                    >
                   {marqueeLearnItems.map((item, index) => (
  <Link
    href={`/learn/${item.slug}`}
    className="homeRailCard"
    key={`${setNumber}-${item.id}-${index}`}
    tabIndex={setNumber === 1 ? -1 : undefined}
  >
    <ContentImage width={400} height={600} sizes="(max-width:600px) 65vw, 260px" loading="lazy"
      src={getLearnCover(item)}
      alt={setNumber === 0 ? item.title : ""}
    />
  </Link>
))}
                    </div>
                  ))}
                </div>
              </div>
            </section>
          )}
        </div>
        {/* BENEFITS STRIP */}
        <section className="homeTrustSection">
          <div className="homeTrustInner">
            <h2>
              Screen Time
              <br />
              You Can Feel Good About
            </h2>

            <div className="homeTrustGrid">
              <div className="homeTrustItem">
                <span>★</span>

                <p>
                  <strong>Original Content</strong>
                  Created for Ages 5–10
                </p>
              </div>

              <div className="homeTrustItem">
                <span>×</span>

                <p>
                  <strong>No Third-Party</strong>
                  Advertising
                </p>
              </div>

              <div className="homeTrustItem">
                <span>●</span>

                <p>
                  <strong>Parent-Managed</strong>
                  Accounts
                </p>
              </div>

              <div className="homeTrustItem">
                <span>▣</span>

                <p>
                  <strong>New Adventures</strong>
                  Added Regularly
                </p>
              </div>

              <div className="homeTrustItem">
                <span>▤</span>

                <p>
                  <strong>Stories &amp; Learning</strong>
                  In One Membership
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* MEMBERSHIP */}
        <section className="homeMembershipSection">
          <div className="homeMembershipIntro">
            <h2>
              Start With 1
              <br />
              Adventure.
              <br />
              Join When They Ask
              <br />
              For the Next One.
            </h2>

            <div className="membershipUnderline" />
          </div>

          <div className="homePlanCard freePlanCard">
            <span className="homePlanLabel">Free Reader</span>

            <ul>
              <li>One complete Read With Luke story</li>
              <li>One complete Learn With Luke adventure</li>
              <li>No payment information required</li>
            </ul>

            <Link href="/free-reads" className="freePlanButton">
              Start Reading Free
            </Link>
          </div>

          <div className="homePlanCard paidPlanCard">
            <span className="homePlanLabel">Full Membership</span>

            <div className="paidPlanContent">
              <ul>
                <li>Unlimited access to all stories</li>
                <li>Unlimited learning adventures</li>
                <li>New releases and continuing series</li>
                <li>Family reading progress and rewards</li>
              </ul>

              <div className="homePlanPrices">
                <strong>
                  $4.99
                  <small>/month</small>
                </strong>
              </div>
            </div>

            <Link href="/signup" className="paidPlanButton">
              Join Today!
            </Link>
          </div>

          <Link href="/gift" className="homeGiftCard">
            <span className="giftEmoji">🎁</span>

            <strong>Gift Reading</strong>

            <p>
              Make storytime happen—even when you’re not there.
            </p>

            <span>
              Give a Gift
              <span aria-hidden="true">→</span>
            </span>
          </Link>
        </section>
      </main>

      <Footer />
    </>
  );
}
