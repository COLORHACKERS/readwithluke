import type { MetadataRoute } from "next";
import { getCatalog } from "@/lib/public-catalog";
import { SITE_URL } from "@/lib/seo";
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const [books, lessons] = await Promise.all([getCatalog("books"), getCatalog("learn_items")]);
  const paths = ["/", "/library", "/learn", "/free-reads", "/about", "/membership", "/gift", "/learn/mushrooms-for-kids"];
  const urls = [
    ...paths.map(path => `${SITE_URL}${path === "/" ? "" : path}`),
    ...books.filter(item => !item.seo_noindex).map(item => `${SITE_URL}/books/${encodeURIComponent(item.slug)}`),
    ...lessons.filter(item => !item.seo_noindex).map(item => `${SITE_URL}/learn/${encodeURIComponent(item.slug)}`),
  ];
  // Never claim a page was modified today when its real edit time is unknown.
  return [...new Set(urls)].map(url => ({ url }));
}
